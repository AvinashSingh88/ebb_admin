

 $(".furniture-tab").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         }); 
 $(".paintss").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
		  $(".kitchens").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
  $(".home-app").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
		   $(".sanitary-tab").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
    $(".plumbing-tab").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
		  $(".electrical").owlCarousel({
           loop: true,
           //margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
		 
         $(".owl-carousel012").owlCarousel({
           loop: true,
           margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
         $(".owl-carousel121").owlCarousel({
           loop: true,
           margin: 10,
           smartSpeed: 700,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
      
         $(".visualizerslider").owlCarousel({
           loop: true,
           margin: 10,
           nav: false,
           dots: false,
           autoplay: true,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
    
         $(".owl-carouselteam").owlCarousel({
           loop: true,
           margin: 10,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
     
         $(".owl-carouselnews").owlCarousel({
           loop: true,
           margin: 10,
           dots: false,
           nav: true,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 2,
             },
           },
         });
    
         $(".owl-carouselblog").owlCarousel({
           loop: true,
           margin: 10,
           dots: false,
           nav: true,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 2,
             },
           },
         });
    
         $(".owl-carousel41").owlCarousel({
           loop: true,
           margin: 30,
           nav: true,
           dots: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 5,
             },
           },
         });
     
         $(".slideR-3").owlCarousel({
           loop: true,
           margin: 10,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 1,
             },
             1000: {
               items: 1,
             },
           },
         });
         $(".owl-tab").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
         $(".owl-tab2").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items:4,
             },
           },
         });
         $(".owl-tab3").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
         $(".owl-tab4").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
		     $(".owl-tab5").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
		      $(".owl-tab6").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
		      $(".owl-tab7").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 4,
             },
           },
         });
		      $(".owl-tab8").owlCarousel({
           loop: true,
           margin: 0,
           autoplay: false,
           dots: true,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items:4,
             },
           },
         });
         $(".tab-product").owlCarousel({
           loop: true,
           margin: 20,
           autoplay: true,
           dots: false,
           nav: false,
           responsive: {
             0: {
               items: 1,
             },
             600: {
               items: 4,
             },
             1000: {
               items: 3,
             },
           },
         });
         
         
     
         setInterval(function() {
            $('.box-dis').each(function() {
                var $li = $(this);
                $li.removeClass('purple-bg')
            });
            var delay = 0;
            $('.box-dis').each(function() {
                var $li = $(this);
                setTimeout(function() {		
                    $li.addClass('purple-bg')
                }, delay += 900)
            })
         }, 8000); 
    