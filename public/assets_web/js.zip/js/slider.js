	$('.owl-carousel_sliders').owlCarousel({
	    loop: true,
	    margin: 10,
	    nav: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.owl-carousel_sliders2').owlCarousel({
	    loop: true,
	    margin: 10,
	    nav: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.category-slide').owlCarousel({
	    loop: false,
	    margin: 3,
	    nav: true,
	    dots: false,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 2
	        },
	        1000: {
	            items: 7
	        }
	    }
	});
	// slider js footer here

	$('.footer-slider').owlCarousel({
	    loop: true,
	    margin: 10,
	    nav: false,
	    dots: false,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 2
	        },
	        1000: {
	            items: 2
	        }
	    }
	});

	jQuery(document).ready(function($) {
	    $('.slick.marquee').slick({
	        speed: 30000,
	        autoplay: true,
	        autoplaySpeed: 1000,
	        centerMode: true,
	        cssEase: 'linear',
	        slidesToShow: 1,
	        slidesToScroll: 1,
	        variableWidth: true,
	        infinite: true,
	        initialSlide: 1,
	        arrows: false,
	        buttons: false
	    });
	});

	jQuery(document).ready(function($) {
	    $('.slick.marquee2').slick({
	        speed: 30000,
	        autoplay: true,
	        autoplaySpeed: 1000,
	        centerMode: true,
	        cssEase: 'linear',
	        slidesToShow: 1,
	        slidesToScroll: 1,
	        variableWidth: true,
	        infinite: true,
	        initialSlide: 1,
	        arrows: false,
	        buttons: false
	    });
	});
	// custom select js end here

	$('.trending0').owlCarousel({
	    loop: true,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.trending021').owlCarousel({
	    loop: true,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.trending4').owlCarousel({
	    loop: true,
	    margin: 15,
	    dots: false,
	    nav: false,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 8
	        }
	    }
	});
	/*  $('.trending').owlCarousel({
	     loop: false,
	     margin: 10,
		 stagePadding: 50,
	     dots: false,
	     nav: true,
		  autoplay: false,
	     responsive: {
	         0: {
	             items: 1
	         },
	         600: {
	             items: 3
	         },
	         1000: {
	             items:4
	         }
	     }

	 }); */
	$('.trending').owlCarousel({
	    loop: false,
	    margin: 10,
	    stagePadding: 0,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }

	});
	$('.categorys_prod').owlCarousel({
	    loop: false,
	    margin: 10,
	    stagePadding: 0,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }

	});


	$('.tab-product2').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});

	$('.trending2').owlCarousel({
	    loop: true,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});
	$('.trending3').owlCarousel({
	    loop: true,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});
	$('.trending001').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});
	$('.trending0091').owlCarousel({
	    loop: false,
	    margin: 5,
	    dots: false,
	    nav: false,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});
	$('.trending00154').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 4
	        }
	    }
	});
	$('.trending0001').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.trending00019').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: true,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 5
	        }
	    }
	});
	$('.trending400').owlCarousel({
	    loop: false,
	    margin: 15,
	    dots: false,
	    nav: false,
	    autoplay: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 8
	        }
	    }
	});

	$(document).ready(function() {
	    $("#rotatezero").click(function() {
	        $(".menu-overlay").toggleClass("add-overlay");
	    });
		
	});
	$(".owl-carousel8").owlCarousel({
	    loop: true,
	    margin: 10,
	    autoplay: true,
	    dots: false,
	    nav: false,
	    autoplayTimeout: 2000,
	    responsive: {
	        0: {
	            items: 1,
	        },
	        600: {
	            items: 3,
	        },
	        1000: {
	            items: 6,
	        },
	    },
	});
	$(".owl-carousel9").owlCarousel({
	    loop: true,
	    margin: 20,
	    autoplay: true,
	    dots: false,
	    nav: false,
	    autoplayTimeout: 2000,
	    responsive: {
	        0: {
	            items: 1,
	        },
	        600: {
	            items: 3,
	        },
	        1000: {
	            items: 6,
	        },
	    },
	});

	jQuery(document).ready(function() {

	    var slides = ['About', 'Work', 'Services', 'Awards'];
	    $('.fp-slidesNav ul li').each(function(i) {
	        $(this).find('a').append('<p class="slide_name">' + slides[i] + '</p>');
	    });

	});
	$(document).ready(function() {
	    $("#searchid").click(function() {
	        $(".search-tab").toggle();
	    });
	    $("#imgrotate").click(function() {
	        $("a#imgrotate img").toggleClass("rotate");
	        $(".right-sidemenu").toggle();
	    });
	    $("#rotatezero").click(function() {
	        $("#rotatezero span").toggleClass("rotatezero");
	        $(".popmenu-container").toggleClass("opened");
	    });

	    $("#shopid").click(function() {
	        $(".top_ul").slideToggle();
	    });
		
		 


	    $(".close-menu").click(function() {
	        $("#rotatezero span").toggleClass("rotatezero");
			$(".menu-overlay").removeClass('add-overlay');
	    });

	});
	var owl = $('.owl-carousel444');
	owl.owlCarousel({
	    items: 1,
	    loop: true,
	    dots: true,
	    margin: 10,
	    autoplay: true,
	    animateOut: 'fadeOut',
	    slideSpeed: 4500,
	    autoplayTimeout: 4500,
	    responsive: {
	        0: {
	            items: 1,
	        },
	        600: {
	            items: 1,
	        },
	        1000: {
	            items: 1,
	        },
	    },
	});
	$('.play').on('click', function() {
	    owl.trigger('play.owl.autoplay', [5000])
	});
	$('.stop').on('click', function() {
	    owl.trigger('stop.owl.autoplay')
	});
	$('a.button.secondary.stop').click(function() {
	    $("a.button.secondary.stop").hide();
	    $("a.button.secondary.play").show();
	});
	$('a.button.secondary.play').click(function() {
	    $("a.button.secondary.play").hide();
	    $("a.button.secondary.stop").show();
	});
	$(".menulocationds5").hover(function() {
	    $('.menulocationds5 .product_submenu').css("opacity", "1");
	    $('.menulocationds5 .product_submenu').css("display", "block");
	}, function() {
	    $('.menulocationds5 .product_submenu').css("display", "none");
	    $('.menulocationds5 .product_submenu').css("opacity", "0");
	});


	$(".menulocationds1").hover(function() {
	    $('.menulocationds1 .megamenu1').css("opacity", "1");
	    $('.menulocationds1 .megamenu1').css("display", "block");
	}, function() {
	    $('.menulocationds1 .megamenu1').css("display", "none");
	    $('.menulocationds1 .megamenu1').css("opacity", "0");
	});




	$(".menulocationds2").hover(function() {
	    $('.menulocationds2 .megamenu2').css("opacity", "1");
	    $('.menulocationds2 .megamenu2').css("display", "block");
	}, function() {
	    $('.menulocationds2 .megamenu2').css("display", "none");
	    $('.menulocationds2 .megamenu2').css("opacity", "0");
	});




	$(".menulocationds3").hover(function() {
	    $('.menulocationds3 .megamenu3').css("opacity", "1");
	    $('.menulocationds3 .megamenu3').css("display", "block");
	}, function() {
	    $('.menulocationds3 .megamenu3').css("display", "none");
	    $('.menulocationds3 .megamenu3').css("opacity", "0");
	});




	$(".menulocationds4").hover(function() {
	    $('.menulocationds4 .megamenu4').css("opacity", "1");
	    $('.menulocationds4 .megamenu4').css("display", "block");
	}, function() {
	    $('.menulocationds4 .megamenu4').css("display", "none");
	    $('.menulocationds4 .megamenu4').css("opacity", "0");
	});










	$('#formRanking2a').owlCarousel({
	    loop: true,
	    margin: 10,
	    autoplay: true,
	    autoplayTimeout: 3000,
	    dots: true,
	    nav: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 3
	        }
	    }
	});




	$('#formRanking3a').owlCarousel({
	    loop: true,
	    margin: 10,
	    autoplay: false,
	    autoplayTimeout: 3000,
	    dots: true,
	    nav: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 1
	        },
	        1000: {
	            items: 1
	        }
	    }
	});


	$(document).ready(function() {

	    var owl = $("#formRanking4a");

	    owl.owlCarousel({
	        navigation: true,
	        autoplay: true,
	        singleItem: true,
	        transitionStyle: "fade",
	        responsive: {
	            0: {
	                items: 1
	            },
	            600: {
	                items: 1
	            },
	            1000: {
	                items: 1
	            }
	        }
	    });

	});

	$(document).ready(function() {

	    var owl = $("#owl-demo");

	    owl.owlCarousel({
	        navigation: true,
	        items: 1,
	        singleItem: true,
	        transitionStyle: "fade"
	    });

	});


	$('#formRanking2a').owlCarousel({
	    loop: true,
	    margin: 10,
	    autoplay: true,
	    autoplayTimeout: 3000,
	    dots: true,
	    nav: true,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 3
	        }
	    }
	});

	/* work page slider text and box animation */

	function work_func() {
	    var duration = 0.4;
	    var ys_position = 30;
	    var yd_position = 0;
	    var work_title = $(".work-introduction .title-color");
	    var w_title = $(".work-introduction .mb-5.title");
	    var readmore = $(".work-introduction .Read_more");
	    var work_list = $(".work-introduction .services_layout ul li");

	    setTimeout(function() {
	        $(".work-introduction .title-color, .work-introduction .mb-5.title, .work-introduction .Read_more").show();
	        $(".work-introduction .services_layout ul li").css("display", "inline-block");

	        TweenMax.fromTo(work_title, duration, { opacity: 0, y: ys_position }, { opacity: 1, y: yd_position, delay: 0.5, ease: Linear.easeOut });
	        TweenMax.staggerFromTo(w_title, duration, { opacity: 0, y: ys_position }, { opacity: 1, y: yd_position, delay: 0.9, ease: Linear.easeOut }, 0.2);
	        TweenMax.fromTo(readmore, duration, { opacity: 0, y: ys_position }, { opacity: 1, y: yd_position, delay: 1.1, ease: Linear.easeOut });
	        TweenMax.staggerFromTo(work_list, duration, { opacity: 0, x: "-=100" }, { opacity: 1, x: 0, delay: 0.9, ease: Linear.easeOut }, 0.4);
	    }, 500);
	}



	/* Call functions on menu click */

	$(document).ready(function() {

	    $(".fp-slidesNav.bottom li:first-child a").click(function() {
	        home_func();
	        $(".work-introduction .title-color, .work-introduction .mb-5.title, .work-introduction .Read_more, .work-introduction .services_layout ul li").hide();
	        $(".service-introduction .service_tsm, .service-introduction .mb-5.title, .service-introduction .services_layout ul li").hide();
	        $(".Homepage_About .about_tsm, .Homepage_About .large_intro_text, .Homepage_About .mb-5.title, .Homepage_About .Read_more").hide();
	    });

	    $(".fp-slidesNav.bottom li:nth-child(2) a").click(function() {
	        work_func();
	        $(".memor_para .watermark, .memor_para .t_small, .memor_para .mb-5.title, .memor_para .Read_more").hide();
	        $(".service-introduction .service_tsm, .service-introduction .mb-5.title, .service-introduction .services_layout ul li").hide();
	        $(".Homepage_About .about_tsm, .Homepage_About .large_intro_text, .Homepage_About .mb-5.title, .Homepage_About .Read_more").hide();
	    });

	    $(".fp-slidesNav.bottom li:nth-child(3) a").click(function() {
	        service_func();
	        $(".memor_para .watermark, .memor_para .t_small, .memor_para .mb-5.title, .memor_para .Read_more").hide();
	        $(".work-introduction .title-color, .work-introduction .mb-5.title, .work-introduction .Read_more, .work-introduction .services_layout ul li").hide();
	        $(".Homepage_About .about_tsm, .Homepage_About .large_intro_text, .Homepage_About .mb-5.title, .Homepage_About .Read_more").hide();
	    });

	    $(".fp-slidesNav.bottom li:nth-child(4) a").click(function() {
	        about_func();
	        $(".memor_para .watermark, .memor_para .t_small, .memor_para .mb-5.title, .memor_para .Read_more").hide();
	        $(".work-introduction .title-color, .work-introduction .mb-5.title, .work-introduction .Read_more, .work-introduction .services_layout ul li").hide();
	        $(".service-introduction .service_tsm, .service-introduction .mb-5.title, .service-introduction .services_layout ul li").hide();
	    });

	    $(".fp-slidesNav.bottom li:nth-child(4) a").click(function() {
	        award_func();
	        $(".heading, img , .Award-introduction .mb-5.title, .Award-introduction p, .Award-introduction .Award-list ul li").hide();
	        $(".heading, img , .Award-introduction .mb-5.title, .Award-introduction p, .Award-introduction .Award-list ul li").hide();
	        $(".service-introduction .service_tsm, .service-introduction .mb-5.title, .service-introduction .services_layout ul li").hide();
	    });



	});



	var loading_works = false;
	var post_masonry = '';
	var bottom_video = false;
	window.requestAnimFrame = (function(callback) {
	    return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
	        function(callback) {
	            window.setTimeout(callback, 1000 / 60);
	        };
	})();
	jQuery(document).ready(function() {

	    var share_scroll_top = jQuery('.social-share-container').offset();

	    jQuery(window).scroll(function(e) {

	        var scroll = $(window).scrollTop();

	        if (jQuery(window).width() > 992) {
	            jQuery("[data-type='parallax']").each(function() {
	                var layer = jQuery(this);
	                topDistance = window.pageYOffset
	                depth = jQuery(this).attr('data-depth');
	                movement = -(topDistance * depth);
	                translate3d = 'translate3d(0, ' + movement + 'px, 0)';
	                jQuery(this).css({

	                    'transform': translate3d
	                })



	            });
	            if (scroll > 200 && !jQuery('.nav-menu-container').hasClass('scrolled')) {
	                jQuery('.nav-menu-container').addClass('scrolled');

	            } else if (scroll < 100 && jQuery('.nav-menu-container').hasClass('scrolled')) {
	                jQuery('.nav-menu-container').removeClass('scrolled');

	            }
	            if (scroll > 200 && !jQuery('body').hasClass('scrolled')) {

	                jQuery('body').addClass('scrolled');
	            } else if (scroll < 100 && jQuery('body').hasClass('scrolled')) {

	                jQuery('body').removeClass('scrolled');
	            }
	        } else {
	            if (scroll > 50 && !jQuery('body').hasClass('scrolled')) {

	                jQuery('body').addClass('scrolled');
	            } else if (scroll < 50 && jQuery('body').hasClass('scrolled')) {

	                jQuery('body').removeClass('scrolled');
	            }
	        }




	        if (jQuery('.our-work-listing-container .pagination').length > 0) {
	            var scroll_top = jQuery('.our-work-listing-container .pagination').offset();
	            // console.log(scroll);
	            // console.log(scroll_top.top);

	            if ((scroll + (jQuery(window).height() - 200)) > scroll_top.top && !loading_works) {
	                load_works_777(true);
	            }
	        }

	        if (jQuery('.section-blog-list .pagination').length > 0) {
	            var scroll_top = jQuery('.section-blog-list .pagination').offset();
	            // console.log(scroll);
	            // console.log(scroll_top.top);

	            if ((scroll + (jQuery(window).height() - 200)) > scroll_top.top && !loading_works) {
	                load_more_posts_777();
	            }
	        }
	        if (jQuery('.home-6 .video .player').length > 0) {

	            var scroll_top = jQuery('.home-6 .video .player').offset();

	            if ((scroll + (jQuery(window).height() - 200)) > scroll_top.top && !bottom_video) {
	                bottom_video = true;
	                if (jQuery(window).width() > 767) {
	                    var video = jQuery('.home-6 .video .player').get(0);
	                    video.play();

	                } else {
	                    /*var src = jQuery('.home-6 .video').data('mobile-image');
	                    jQuery('.home-6 .video .player').remove();
	                    jQuery('.home-6 .video').append('<img src="'+src+'" class="img-fluid" alt=""/>');*/
	                }
	            }



	        }
	        if (jQuery('.social-share-container').length > 0) {

	            var recommanded_post_scroll = jQuery('.section-recommended-post').offset();

	            if (!jQuery('.social-share-container').hasClass('fixed') && scroll > share_scroll_top.top && scroll < recommanded_post_scroll.top) {
	                jQuery('.social-share-container').addClass('fixed');
	            } else if (jQuery('.social-share-container').hasClass('fixed') && (scroll < share_scroll_top.top || scroll > recommanded_post_scroll.top)) {
	                console.log(scroll);
	                console.log(share_scroll_top.top);
	                jQuery('.social-share-container').removeClass('fixed');
	            }

	        }

	    }).scroll();
	    if (jQuery(window).outerWidth() < 767) {
	        if (jQuery('.full-height-mobile').length > 0) {
	            jQuery('.full-height-mobile').height(jQuery(window).outerHeight());
	        }
	    }
	    if (jQuery('.image-with-video').length > 0) {
	        jQuery('.image-with-video-container,.background-object').click(function() {
	            $.magnificPopup.open({
	                items: {
	                    src: jQuery('.image-with-video-container .home-landing-popup-video').clone()
	                },
	                type: 'inline',
	                callbacks: {
	                    open: function() {
	                        video_home_popup = new Plyr('.mfp-content .home-landing-popup-video .player', {
	                            autoplay: true
	                        });



	                    },
	                    close: function() {
	                            // Will fire when popup is closed
	                            jQuery('.mfp-content .video-inner-popup .plyr').remove();
	                        }
	                        // e.t.c.
	                }
	            });

	            jQuery('.home-landing-popup-video .player')


	        });
	        $(window).load(function() {
	            if (jQuery('.landing-video-container').length > 0) {
	                var video_landing = jQuery('.landing-video-container .player').get(0);
	                video_landing.play()



	            }
	        });

	    }

	    if (jQuery('.ourservice-video-slider .video-container .video').length > 0) {
	        jQuery('.ourservice-video-slider .video-container .video').click(function() {


	            $.magnificPopup.open({
	                items: {
	                    src: jQuery(this).find(' .video-inner-popup').clone()
	                },
	                type: 'inline',
	                callbacks: {
	                    open: function() {
	                        new Plyr('.mfp-content .video-inner-popup .player', {

	                            autoplay: true,
	                        });
	                    },
	                    beforeClose: function() {
	                            jQuery('.mfp-content .video-inner-popup .plyr').remove();
	                        }
	                        // e.t.c.
	                }
	            });




	        });
	    }
	    if (jQuery('.logos-background').length > 0) {


	        if (jQuery(window).width() < 767) {
	            jQuery('.logos-background').remove()
	        } else {
	            var total_width = (jQuery('.logos-background').data('total-logo') * jQuery('.client-logo').outerWidth()) * 1;
	            jQuery('.mani-row-container').width(total_width + 'px');

	            var styles = "<style>.mani-row-container.style1{ animation-duration: " + total_width * 0.01 + "s; }.mani-row-container.style2{ animation-duration: " + ((total_width * 0.01) + 50) + "s; } .mani-row-container.style3{ animation-duration: " + ((total_width * 0.01) + 100) + "s; }</style>"
	            jQuery('html').append(styles);
	        }
	    }
	    if (jQuery('.featuerd-work-video-slider .video-container .video').length > 0) {
	        jQuery('.featuerd-work-video-slider .video-container .video').click(function() {


	            $.magnificPopup.open({
	                items: {
	                    src: jQuery(this).find(' .video-inner-popup').clone()
	                },
	                type: 'inline',
	                callbacks: {
	                    open: function() {
	                        new Plyr('.mfp-content .video-inner-popup .player', {

	                            autoplay: true,
	                        });
	                    },
	                    beforeClose: function() {
	                            jQuery('.mfp-content .video-inner-popup .plyr').remove();

	                        }
	                        // e.t.c.
	                }
	            });

	        });
	        jQuery('.home-4 .play-btn').click(function() {

	            $.magnificPopup.open({
	                items: {
	                    src: jQuery(this).closest('.home-4').find('.slick-active .video-inner-popup').clone()
	                },
	                type: 'inline',
	                callbacks: {
	                    open: function() {
	                        new Plyr('.mfp-content .video-inner-popup .player', {

	                            autoplay: true,
	                        });
	                    },
	                    beforeClose: function() {
	                            jQuery('.mfp-content .video-inner-popup .plyr').remove();

	                        }
	                        // e.t.c.
	                }
	            });
	        });
	    }
	    if (jQuery('.section-home .image-with-video-container').length > 0 && jQuery(window).width() > 767) {
	        jQuery('.section-home .image-with-video-container')

	        var height = jQuery(window).height() - 20;
	        if (jQuery('.section-home .image-with-video-container').height() > height) {
	            jQuery('.section-home .image-with-video-container').css({
	                'height': height + 'px'
	            });
	        }

	    }
	    if (jQuery('.ourservice-video-slider').length > 0) {
	        jQuery('.ourservice-video-slider').slick({
	            infinite: true,
	            slidesToShow: 1,
	            slidesToScroll: 1,
	            dots: true,
	            arrows: false,
	            autoplay: true,
	            autoplaySpeed: 5000,
	        });
	    }
	    if (jQuery('.featuerd-work-video-slider').length > 0) {
	        jQuery('.featuerd-work-video-slider').slick({
	            infinite: true,
	            slidesToShow: 1,
	            slidesToScroll: 1,
	            dots: true,
	            arrows: true,
	            prevArrow: '<a class="slick-arrow arrow-prev"><span class="lnr lnr-chevron-left"></span></a>',
	            nextArrow: '<a class="slick-arrow arrow-next"><span class="lnr lnr-chevron-right"></span></a>',
	            autoplay: true,
	            autoplaySpeed: 5000,
	        });
	    }
	    if (jQuery('.slider-service-callout').length > 0) {
	        jQuery('.slider-service-callout').slick({
	            infinite: true,
	            slidesToShow: 1,
	            slidesToScroll: 1,
	            dots: true,
	            arrows: true,
	            prevArrow: '<a class="slick-arrow arrow-prev"><i class="fas fa-angle-left"></span></a>',
	            nextArrow: '<a class="slick-arrow arrow-next"><span class="fas fa-angle-right"></span></a>',
	            autoplay: true,
	            autoplaySpeed: 5000,
	        });
	    }
	    if (jQuery('.mobile-logo-slider').length > 0 && jQuery(window).width() < 767) {
	        jQuery('.mobile-logo-slider').slick({
	            infinite: true,
	            slidesToShow: 1,
	            slidesToScroll: 1,
	            dots: false,
	            arrows: true,
	            prevArrow: '<a class="slick-arrow arrow-prev"><i class="fas fa-angle-left"></span></a>',
	            nextArrow: '<a class="slick-arrow arrow-next"><span class="fas fa-angle-right"></span></a>',
	            autoplay: true,
	            autoplaySpeed: 5000,
	        });
	    }
	    if (jQuery('.humberg-menu').length > 0) {
	        jQuery('.humberg-menu').click(function(e) {
	            e.preventDefault();
	            if (jQuery('body').hasClass('humbered-open')) {
	                jQuery('body').removeClass('humbered-open');
	                jQuery('.popmenu-container').removeClass('opened');
	            } else {
	                jQuery('body').addClass('humbered-open');
	                jQuery('.popmenu-container').addClass('opened');
	            }
	        });

	        jQuery('.close-menu').click(function(e) {
	            e.preventDefault();


	            jQuery('body').removeClass('humbered-open');
	            jQuery('.popmenu-container').removeClass('opened');

	        });
	    }

	    if (jQuery('.popmenu-content #menu-big-menu li').length > 0) {
	        jQuery('.popmenu-content #menu-big-menu li').hover(function(e) {
	            e.preventDefault();
	            jQuery('.popup-image-slider .item-image.active').removeClass('active');

	            jQuery('.popup-image-slider #item-image-' + jQuery(this).attr('id') + '.item-image').addClass('active');
	        });
	    }




	    if (jQuery('.menu-hover-canvas').length > 0)

	    {
	        jQuery('.menu-hover-canvas').each(function(i, v) {

	            //  Define Canvas & Context
	            // console.log(i);
	            jQuery(this).css({ 'height': (jQuery(this).closest('li').find('a').outerWidth() + 20) + 'px' });
	            jQuery(this).css({ 'margin-left': '-' + ((jQuery(this).outerWidth()) / 2) + 'px' });
	            // console.log(jQuery(this).outerWidth());
	            // console.log(jQuery(this).closest('li').outerWidth());



	        });



	    }

	    if (jQuery('.gallery-video-open').length > 0) {
	        var services_video = [];
	        jQuery('.gallery-video-open').each(function() {
	            services_video.push({ src: jQuery(jQuery(this).attr('href')).clone() });

	        });

	        jQuery('.gallery-video-open').click(function(e) {
	            e.preventDefault();
	            var index = jQuery('.gallery-video-open').index(this);
	            // console.log(index);
	            jQuery.magnificPopup.open({
	                items: services_video,
	                type: 'inline',
	                closeOnContentClick: false,
	                closeOnBgClick: false,
	                gallery: {
	                    enabled: true,
	                    arrowMarkup: '<button title="%title%" type="button" class="magnificpop-slider-arrow arrow-%dir%"><i class="fas fa-angle-%dir%"></i></button>', // markup of an arrow button
	                },
	                callbacks: {
	                    open: function() {
	                        jQuery('html').addClass('blued-everythings');

	                        new Plyr('.mfp-content .video-container .player', {

	                            autoplay: true,
	                        });
	                    },
	                    elementParse: function(item) {
	                        // Function will fire for each target element
	                        // "item.el" is a target DOM element (if present)
	                        // "item.src" is a source that you may modify

	                        // console.log('Parsing content. Item object that is being parsed:', item);
	                    },
	                    markupParse: function() {

	                    },
	                    close: function() {
	                        jQuery('html').removeClass('blued-everythings');
	                    },
	                    beforeClose: function() {
	                        jQuery('.mfp-content .video-inner-popup .plyr').remove();

	                    }

	                }

	                // You may add options here, they're exactly the same as for $.fn.magnificPopup call
	                // Note that some settings that rely on click event (like disableOn or midClick) will not work here
	            }, (index));
	        });
	        // add this code after popup JS file is included
	        $.magnificPopup.instance.next = function() {
	            // console.log('Parsing content. Item object that is being parsed:');
	            // Do something
	            // You may call parent ("original") method like so:
	            $.magnificPopup.proto.next.call(this /*, optional arguments */ );
	            new Plyr('.mfp-content .video-container .player', {

	                autoplay: true,
	            });

	        };
	    }


	    if (jQuery('.our-work-search-container').length > 0) {
	        refres_video_on_ajax();
	        jQuery('.search-fitler-badge').css({
	            'margin-top': '-' + (jQuery('.search-fitler-badge').outerWidth() / 2) + 'px'
	        });
	        jQuery('.our-work-search-container select').selectric({
	            arrowButtonMarkup: '<div class="cbutton"></div>'
	        }).on('change', function() {
	            var search_text = [];
	            var clear_disabled = true;
	            jQuery('.our-work-search-container select').each(function() {
	                if (jQuery(this).val() != '') {
	                    clear_disabled = false;
	                    search_text.push(jQuery(this).find("option:selected").html());
	                }
	            });
	            if (clear_disabled == false) {
	                jQuery('.search-fitler-badge').text(search_text.toString());
	            } else {
	                jQuery('.search-fitler-badge').text('All Work');
	            }
	            jQuery('.search-fitler-badge').css({
	                'margin-top': '-' + (jQuery('.search-fitler-badge').outerWidth() / 2) + 'px'
	            });
	            jQuery('.our-work-search-container .clear-btn').attr({ 'disabled': clear_disabled });
	            load_works_777(false);



	        });
	        jQuery('#work-search-clear').click(function(e) {

	            e.preventDefault();
	            jQuery('.our-work-search-container select').val('');
	            jQuery('.our-work-search-container select').selectric('refresh').change();
	        });


	    }
	    if (jQuery('.activecampaign-form-container').length > 0) {
	        jQuery('.activecampaign-form-container select').selectric({
	            arrowButtonMarkup: '<div class="cbutton"></div>'
	        });
	    }
	    if (jQuery('.apply-for-job').length > 0) {
	        jQuery('.apply-for-job').click(function() {
	            jQuery.magnificPopup.open({
	                items: {
	                    src: '#apply-for-job-form'
	                },
	                type: 'inline',


	                callbacks: {
	                    open: function() {
	                        jQuery('html').addClass('blued-everythings');

	                    },
	                    close: function() {
	                        jQuery('html').removeClass('blued-everythings');
	                    }

	                }

	            });
	        });
	    }
	    if (jQuery('.our-process-navs').length > 0) {
	        jQuery('.our-process-navs li a').click(function(e) {
	            e.preventDefault();
	            jQuery('.our-process-navs li.active').removeClass('active');
	            jQuery(this).closest('li').addClass('active');
	            // console.log(jQuery(this).attr('href'));
	            $.scrollify.move(jQuery(this).attr('href'));

	        });

	        jQuery('.mobile-our-process_menu li a').click(function(e) {
	            e.preventDefault();

	            jQuery(this).closest('.mobile-our-process_menu').find('.menu').hide();
	            // console.log(jQuery(this).attr('href'));
	            // console.log(jQuery(jQuery(this).attr('href')).offset().top);
	            jQuery("html, body").animate({ scrollTop: jQuery(jQuery(this).attr('href')).offset().top }, "slow");

	        });

	        if (jQuery(window).width() > 767) {
	            jQuery.scrollify({
	                section: ".site-main .scrollify-section",
	                interstitialSection: '.site-footer',
	                standardScrollElements: '.site-footer',

	                before: function(index, sections) {
	                    jQuery('.our-process-navs li.active').removeClass('active');
	                    if (index != 0) {

	                        jQuery('.our-process-navs li:eq(' + (index - 1) + ')').addClass('active');
	                    } else {

	                    }

	                }
	            });
	        }


	        jQuery('.mobile-our-process_menu .open-menu-button').click(function(e) {
	            e.preventDefault();
	            jQuery(this).closest('.mobile-our-process_menu').find('.menu').toggle();
	        });
	    }
	    if (jQuery('.section-blog-list .blog-list-item').length > 0) {
	        if (jQuery(window).outerWidth() > 767) {
	            /*jQuery('.section-blog-list .blog-list-item .header').each(function(){
	            	jQuery(this).css({'max-width':jQuery(this).closest('.blog-list-item').outerHeight()+'px'});
	            });	*/
	        }

	        jQuery('.blog-select-cat').selectric({
	            arrowButtonMarkup: '<div class="cbutton"></div>'
	        });
	        jQuery('.blog-select-cat').change(function() {
	            window.location = jQuery(this).val();
	        });

	        if (jQuery(window).outerWidth() > 767) {
	            /*post_masonry = jQuery('.blog-list-inner').masonry({
	              // options
	              itemSelector: '.item',
	              
	            });*/
	        }



	    }
	    if (jQuery('#menu-canvas').length > 0) {

	        var canvas = jQuery('#menu-canvas')[0];


	        var ctx = canvas.getContext("2d");

	        jQuery('.nav-menu-container').mousemove(function(e) {

	            canvas_mouse_move(e, canvas, ctx);

	        });
	        jQuery('.nav-menu-container').hover(function(e) {
	            // jQuery('.nav-menu-container').off('mousemove');

	        }, function(e) {
	            ctx.clearRect(0, 0, canvas.width, canvas.height);
	        });


	    }
	    if (jQuery('.section-thank-you-banner .blog-badge').length > 0) {

	        jQuery('.section-thank-you-banner .blog-badge .button').css({
	            'width': jQuery('.section-thank-you-banner .blog-badge').outerHeight() + 'px',

	        });
	        jQuery('.section-thank-you-banner .blog-badge .button').css({

	            'left': '-' + ((jQuery('.section-thank-you-banner .blog-badge ').outerHeight() / 2) - (jQuery('.section-thank-you-banner .blog-badge .button').outerHeight() / 2)) + 'px'
	        });

	    }

	    if (jQuery('.social_share_links li a').length > 0) {
	        jQuery(document).on('click', '.social_share_links li a', function(e) {
	            e.preventDefault();
	            if (jQuery(this).hasClass('copy-link')) {
	                copyToClipboard($(this).attr('href'));

	            } else {
	                var left = ($(window).width() / 2) - (900 / 2),
	                    top = ($(window).height() / 2) - (600 / 2),
	                    popup = window.open(jQuery(this).attr('href'), "popup", "width=900, height=600, top=" + top + ", left=" + left);
	            }
	        });

	    }


	});

	function copyToClipboard($text) {
	    var success = true,
	        range = document.createRange(),
	        selection;

	    // For IE.
	    if (window.clipboardData) {
	        window.clipboardData.setData("Text", $text);
	    } else {
	        // Create a temporary element off screen.
	        var tmpElem = $('<div>');
	        tmpElem.css({
	            position: "absolute",
	            left: "-1000px",
	            top: "-1000px",
	        });
	        // Add the input value to the temp element.
	        tmpElem.text($text);
	        $("body").append(tmpElem);
	        // Select temp element.
	        range.selectNodeContents(tmpElem.get(0));
	        selection = window.getSelection();
	        selection.removeAllRanges();
	        selection.addRange(range);
	        // Lets copy.
	        try {
	            success = document.execCommand("copy", false, null);
	        } catch (e) {
	            copyToClipboardFF($text);
	        }
	        if (success) {
	            alert("The text is on the clipboard, try to paste it!");
	            // remove temp element.
	            tmpElem.remove();
	        }
	    }
	}

	function drawCurve(canvas, points, context) {

	    var height = canvas.height;
	    var width = canvas.width;
	    context.clearRect(0, 0, width, height);

	    var height_factor = height / 100;
	    var width_factor = width / 100;

	    var start = { x: 0, y: 100 * height_factor };
	    var end = { x: 100 * width_factor, y: 100 * height_factor };

	    context.beginPath();
	    context.moveTo(points[0][0].x, points[0][0].y);



	    jQuery.each(points, function(i, v) {
	        //console.log(v);
	        context.bezierCurveTo(v[0].x, v[0].y, v[1].x, v[1].y, v[2].x, v[2].y);
	    });



	    context.fillStyle = "#F1F0F0";

	    context.fill();
	}
	var farme_start = 300;

	var mouse = { x: 0, y: 0 };
	var last_mouse = { x: 0, y: 0 };

	function canvas_mouse_move(e, canvas, ctx) {
	    canvas.width = jQuery('#menu-canvas').outerWidth();
	    canvas.height = jQuery('#menu-canvas').outerHeight();

	    var height_factor = canvas.height / 100;
	    var width_factor = canvas.width / 100;

	    mouse.x = typeof e.offsetX !== 'undefined' ? e.offsetX : e.layerX;
	    mouse.y = typeof e.offsetY !== 'undefined' ? e.offsetY : e.layerY;
	    var target = $(e.target);
	    if (target.is(".hover-element") || target.is(".nav-link") || target.is(".menu-item") || target.is(".nav-link-span")) {

	        //console.log(target);

	        var ele_obj = '';
	        if (target.is(".hover-element"))
	            ele_obj = target;
	        else if (target.is(".nav-link") || target.is(".nav-link-span"))
	            ele_obj = target.closest('li').find('.hover-element');
	        else
	            ele_obj = target.find('.hover-element');

	        //console.log(ele_obj); 
	        var height_ele_factor = ele_obj.height() / 100;
	        var position_x = ele_obj.offset().top - jQuery('.nav-menu-container').offset().top;

	        ctx.clearRect(0, 0, canvas.width, canvas.height);
	        ctx.beginPath();

	        ctx.moveTo(position_x, 100 * height_factor);

	        var end_points = [

	            [
	                { x: position_x, y: 100 * height_factor },
	                { x: position_x + (12.06 * height_ele_factor), y: 95 * height_factor },
	                { x: position_x + (21.59 * height_ele_factor), y: 73 * height_factor }

	            ],

	            [
	                { x: position_x + (34.74 * height_ele_factor), y: 36 * height_factor },
	                { x: position_x + (41.78 * height_ele_factor), y: 17 * height_factor },
	                { x: position_x + (50 * height_ele_factor), y: 17 * height_factor }

	            ],
	            [
	                { x: position_x + (58.21 * height_ele_factor), y: 17 * height_factor },
	                { x: position_x + (65.26 * height_ele_factor), y: 36 * height_factor },
	                { x: position_x + (78.41 * height_ele_factor), y: 73 * height_factor }

	            ],
	            [
	                { x: position_x + (87.94 * height_ele_factor), y: 95 * height_factor },
	                { x: position_x + (100 * height_ele_factor), y: 100 * height_factor },
	                { x: position_x + (100 * height_ele_factor), y: 100 * height_factor }

	            ]
	        ];

	        var start_points = [

	            [
	                { x: position_x, y: 100 * height_factor },
	                { x: position_x + (11.26 * height_ele_factor), y: 92.68 * height_factor },
	                { x: position_x + (21.12 * height_ele_factor), y: 80.48 * height_factor }

	            ],

	            [
	                { x: position_x + (26.76 * height_ele_factor), y: 75.60 * height_factor },
	                { x: position_x + (42.25 * height_ele_factor), y: 60 * height_factor },
	                { x: position_x + (50 * height_ele_factor), y: 60 * height_factor }

	            ],
	            [
	                { x: position_x + (57.75 * height_ele_factor), y: 60 * height_factor },
	                { x: position_x + (73.24 * height_ele_factor), y: 75.60 * height_factor },
	                { x: position_x + (78.88 * height_ele_factor), y: 80.48 * height_factor }

	            ],
	            [
	                { x: position_x + (88.74 * height_ele_factor), y: 92.68 * height_factor },
	                { x: position_x + (100 * height_ele_factor), y: 100 * height_factor },
	                { x: position_x + (100 * height_ele_factor), y: 100 * height_factor }

	            ]
	        ];
	        farme_start = 300;

	        drawCurve(canvas, end_points, ctx);



	        ctx.fillStyle = "#F1F0F0";
	        ctx.fill();
	    } else {
	        ele_obj = jQuery(".hover-element");

	        var height_ele_factor = ele_obj.height() / 100;
	        ctx.clearRect(0, 0, canvas.width, canvas.height);
	        var position_x = mouse.x - (ele_obj.outerHeight() / 2);

	        ctx.beginPath();


	        ctx.moveTo(position_x, 100 * height_factor);


	        ctx.bezierCurveTo(position_x, 100 * height_factor,
	            position_x + (11.26 * height_ele_factor), 92.68 * height_factor,
	            position_x + (21.12 * height_ele_factor), 80.48 * height_factor
	        );

	        ctx.bezierCurveTo(position_x + (26.76 * height_ele_factor), 75.60 * height_factor,
	            position_x + (42.25 * height_ele_factor), 60 * height_factor,
	            position_x + (50 * height_ele_factor), 60 * height_factor
	        );

	        ctx.bezierCurveTo(position_x + (57.75 * height_ele_factor), 60 * height_factor,
	            position_x + (73.24 * height_ele_factor), 75.60 * height_factor,
	            position_x + (78.88 * height_ele_factor), 80.48 * height_factor
	        );

	        ctx.bezierCurveTo(position_x + (88.74 * height_ele_factor), 92.68 * height_factor,
	            position_x + (100 * height_ele_factor), 100 * height_factor,
	            position_x + (100 * height_ele_factor), 100 * height_factor
	        );



	        ctx.fillStyle = "#F1F0F0";
	        ctx.fill();
	    }

	    //console.log(mouse);
	}

	function refres_video_on_ajax() {

	}

	function load_more_posts_777() {

	    if (loading_works)
	        return '';

	    loading_works = true;
	    jQuery('.section-blog-list .loader').show();
	    jQuery('#load-more-post #counter').val(jQuery('.blog-list-inner .blog-list-item').length);

	    jQuery.ajax({
	        method: "POST",
	        url: php_object.ajax_url,
	        data: jQuery('#load-more-post').serialize(),
	        success: function(data) {
	            //console.log(data);
	            if (data != '') {


	                jQuery('.blog-list-inner').append(data);
	                jQuery('#load-more-post #page').val(parseInt(jQuery('#load-more-post #page').val()) + 1);

	            } else {
	                jQuery('.section-blog-list .pagination').remove();
	            }
	            loading_works = false;
	            jQuery('.section-blog-list .loader').hide();

	        }
	    });

	}

	function load_works_777(append) {
	    if (loading_works)
	        return '';

	    // console.log(append);
	    jQuery('.section-our-work-listing .last-added').removeClass('last-added');
	    if (!append) {
	        jQuery('.search-form #page').val(0);
	    }

	    loading_works = true;
	    jQuery('.our-work-listing-container .loader').show();
	    jQuery.ajax({
	        method: "POST",
	        url: php_object.ajax_url,
	        data: jQuery('.search-form').serialize(),
	        success: function(data) {
	            // console.log(data);
	            if (data != '') {
	                if (append) {
	                    jQuery('.our-work-listing .row').append(data);

	                } else {

	                    jQuery('.our-work-listing .row').html(data);
	                    jQuery('.our-work-listing-container').append("<div class='pagination'></div>");
	                }
	                jQuery('.search-form #page').val(parseInt(jQuery('.search-form #page').val()) + 1);
	                refres_video_on_ajax();
	            } else {
	                jQuery('.our-work-listing-container .pagination').remove();
	            }
	            loading_works = false;
	            jQuery('.our-work-listing-container .loader').hide();

	        }
	    });
	};
	/* $('#multi').mdbRange({
	  single: {
	    active: true,
	    multi: {
	      active: true,
	      rangeLength: 1
	    },
	  }
	}); */

	$('.owl-carousele45').owlCarousel({
	    loop: true,
	    margin: 10,
	    nav: false,
	    dots: false,
	    responsive: {
	        0: {
	            items: 1
	        },
	        600: {
	            items: 3
	        },
	        1000: {
	            items: 7
	        }
	    }
	});

	$('.link-category1a').on('click', function() {
	    $('.link-category1a').toggleClass('in');
	});
	$('.link-category1').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category1').addClass('in').siblings().removeClass('in');
	});

	$('.link-category2').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category2').addClass('in');
	});

	$('.link-category3').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category3').addClass('in');
	});

	$('.link-category4').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category4').addClass('in');
	});

	$('.link-category5').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category5').addClass('in');
	});

	$('.link-category6').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category6').addClass('in');
	});

	$('.link-category7').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category7').addClass('in');
	});

	$('.link-category8').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category8').addClass('in');
	});

	$('.link-category9').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category9').addClass('in');
	});

	$('.link-category10').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category10').addClass('in');
	});

	$('.link-category11').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category11').addClass('in');
	});
	$('.link-category12').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category12').addClass('in');
	});
	$('.link-category13').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category13').addClass('in');
	});
	$('.link-category14').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category14').addClass('in');
	});
	$('.link-category15').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category15').addClass('in');
	});
	$('.link-category11').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category11').addClass('in');
	});
	$('.link-category16').on('click', function() {
	    $('.link-category').removeClass('in');
	    $('.link-category16').addClass('in');
	});

	$('span.link-collapse__default').on('click', function() {
	    $('.collapses').show();
	    $('span.link-collapse__default').hide();
	    $('span.link-collapse__active').show();
	});


	$('span.link-collapse__active').on('click', function() {
	    $('.collapses').hide();
	    $('span.link-collapse__active').hide();
	    $('span.link-collapse__default ').show();
	});

	$('span.link-collapse__default2').on('click', function() {
	    $('.collapses2').show();
	    $('span.link-collapse__default2').hide();
	    $('span.link-collapse__active2').show();
	});

	$('span.link-collapse__active2').on('click', function() {
	    $('.collapses2').hide();
	    $('span.link-collapse__active2').hide();
	    $('span.link-collapse__default2 ').show();
	});


	$('span.link-collapse__default3').on('click', function() {
	    $('.collapses3').show();
	    $('span.link-collapse__default3').hide();
	    $('span.link-collapse__active3').show();
	});

	$('span.link-collapse__active3').on('click', function() {
	    $('.collapses3').hide();
	    $('span.link-collapse__active3').hide();
	    $('span.link-collapse__default3 ').show();
	});

	$('span.link-collapse__default4').on('click', function() {
	    $('.collapses4').show();
	    $('span.link-collapse__default4').hide();
	    $('span.link-collapse__active4').show();
	});

	$('span.link-collapse__active4').on('click', function() {
	    $('.collapses4').hide();
	    $('span.link-collapse__active4').hide();
	    $('span.link-collapse__default4 ').show();
	});

	$('span.link-collapse__default5').on('click', function() {
	    $('.collapses5').show();
	    $('span.link-collapse__default5').hide();
	    $('span.link-collapse__active5').show();
	});

	$('span.link-collapse__active5').on('click', function() {
	    $('.collapses5').hide();
	    $('span.link-collapse__active5').hide();
	    $('span.link-collapse__default5 ').show();
	});

	$('span.link-collapse__default6').on('click', function() {
	    $('.collapses6').show();
	    $('span.link-collapse__default6').hide();
	    $('span.link-collapse__active6').show();
	});

	$('span.link-collapse__active6').on('click', function() {
	    $('.collapses6').hide();
	    $('span.link-collapse__active6').hide();
	    $('span.link-collapse__default6 ').show();
	});

	$('span.link-collapse__default7').on('click', function() {
	    $('.collapses7').show();
	    $('span.link-collapse__default7').hide();
	    $('span.link-collapse__active7').show();
	});

	$('span.link-collapse__active7').on('click', function() {
	    $('.collapses7').hide();
	    $('span.link-collapse__active7').hide();
	    $('span.link-collapse__default7 ').show();
	});

	$('span.link-collapse__default8').on('click', function() {
	    $('.collapses8').show();
	    $('span.link-collapse__default8').hide();
	    $('span.link-collapse__active8').show();
	});

	$('span.link-collapse__active8').on('click', function() {
	    $('.collapses8').hide();
	    $('span.link-collapse__active8').hide();
	    $('span.link-collapse__default8 ').show();
	});
	$(".edit-address").click(function() {
	    $(".edit_address_form").show();
	    $(".edit_address_form_new").hide();
	});
	$(".edit-address1").click(function() {
	    $(".edit_address_form").hide();
	});
	$(".edit-address_1").click(function() {
	    $(".edit_address_form_new").show();
	    $(".edit_address_form").hide();
	});
	$(".edit-address1_1").click(function() {
	    $(".edit_address_form_new").hide();
	});