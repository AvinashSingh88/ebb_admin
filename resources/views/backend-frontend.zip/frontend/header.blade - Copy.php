
    <div class="header">
        <div class="topHeader">
           <div class="container">
              <div class="row">
                 <div class="col-sm-2 col-12">
                    <ul class="s_m">
                       <li>
                          <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-square"></i
                             ></a>
                       </li>
                       <li>
                          <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i
                             ></a>
                       </li>
                       <li>
                          <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i
                             ></a>
                       </li>
                       <li>
                          <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin"></i
                             ></a>
                       </li>
                       <li>
                          <a href="https://web.skype.com/" target="_blank"><i class="fab fa-skype"></i
                             ></a>
                       </li>
                    </ul>
                 </div>
                 <div class="col-sm-10 col-12">
                    <div class="t_c right-text">
                       <ul>
                          <li>
                             <a href="advertise.php"><i class="fas fa-volume-up"></i> Advertise</a>
                          </li>
                          <li>
                             <a href="javascript:void(0);"><i class="fa-solid fa-download animated infinite slideInDown"></i>Brochure</a>
                          </li>
                          <li>
                             <a href="enquiry.php"><i class="far fa-question-circle"></i> Enquiry</a>
                          </li>
                          <li>
                             <a href="become_seller.php"><i class="fas fa-archway"></i> Become a Seller</a>
                          </li>
                          <li>
                             <a href="help_center.php"><i class="far fa-question-circle"></i> Help Center</a>
                          </li>
                          <li class="cartonlog">
                             <a href="#t.php">Appointment</a>
                          </li>
                          <li>
                             <a href="bulk-order2.php"><i class="fas fa-truck"></i> Bulk Order</a>
                          </li>
                          <li>
                             <a href="#track-order.php"><i class="fas fa fa-cube"></i> Track Order </a>
                          </li>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <nav>
     <header class="site-header">
        <div class="pt-2 pb-2 search-bar">
           <div class="container">
              <div class="row">
                 <div class="col-md-2 col-sm-2 col-xs-12">
                    <div class="logo-img">
                       <div class="nav-trigger" id="rotatezero">
                          <span></span>
                          <span></span>
                          <span></span>
                       </div>
                       <a href="index.php"><img src="{{static_asset('assets_web
                       /img/logo.png')}}" alt="" /></a>
                    </div>
                 </div>
                 <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="search-box">
                       <div class="select-box custom-select">
                          <select class="form-control">
                             <option value="mumbai">Delhi</option>
                             <option value="Ahmedabad">Faridabad</option>
                             <option value="Delhi">Ghaziabad</option>
                             <option value="Chennai">Gurgaon</option>
                             <option value="mumbai">Noida</option>
                             <option value="mumbai">Delhi</option>
                             <option value="Ahmedabad">Faridabad</option>
                             <option value="Delhi">Ghaziabad</option>
                             <option value="Chennai">Gurgaon</option>
                             <option value="mumbai">Noida</option>
                          </select>
                       </div>
                       <div class="select-search">
                          <input
                             type="search"
                             class="form-control"
                             placeholder="What are you looking for.."
                             id="searchid"
                             />
                          <div class="search-tab">
                             <!-- tab menu start here -->
                             <div class="submenu submenu3">
                                <div class="menuleft menuleft3">
                                   <div class="tabbable-panel">
                                      <div class="tabbable-line">
                                         <ul class="nav nav-tabs">
                                            <li class="active">
                                               <a href="#tab_default_1" data-toggle="tab"
                                                  >Products</a
                                                  >
                                            </li>
                                            <li>
                                               <a href="#tab_default_2" data-toggle="tab"
                                                  >Suppliers</a
                                                  >
                                            </li>
                                         </ul>
                                         <div class="tab-content">
                                            <div class="tab-pane active" id="tab_default_1">
                                               <ul class="ulinesdmen">
                                                  <li>
                                                     <i class="fas fa-search"></i> Services1
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services2
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services3
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services4
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services5
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services6
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services7
                                                  </li>
                                               </ul>
                                            </div>
                                            <div class="tab-pane" id="tab_default_2">
                                               <ul class="ulinesdmen">
                                                  <li>
                                                     <i class="fas fa-search"></i> Services7
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services6
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services5
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services4
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services3
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services2
                                                  </li>
                                                  <li>
                                                     <i class="fas fa-search"></i> Services1
                                                  </li>
                                               </ul>
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                                <div class="menuright menuright3">
                                   <ul>
                                      <li>
                                         <a href="technology-expertise#tab2">
                                         <img
                                            class="lazyloaded"
                                            src="img/technology-menu-icon.svg"
                                            data-src="img/technology-menu-icon.svg"
                                            alt="Technology"
                                            width="44"
                                            />
                                         <span
                                            ><strong>Technology</strong> What we are good
                                         at!</span
                                            ></a
                                            >
                                      </li>
                                      <li>
                                         <a href="4p"
                                            ><img
                                            src="img/4p-menu-icon.svg"
                                            alt="4p"
                                            width="44"
                                            />
                                         <span
                                            ><strong>4P</strong> Our winning
                                         proposition.</span
                                            ></a
                                            >
                                      </li>
                                      <li>
                                         <a href="models"
                                            ><img
                                            src="img/models-menu-icon.svg"
                                            alt="models"
                                            width="44"
                                            />
                                         <span
                                            ><strong>Models</strong> We know what is best
                                         for you.</span
                                            ></a
                                            >
                                      </li>
                                      <li>
                                         <a href="agile-and-scrum"
                                            ><img
                                            class="lazyloaded"
                                            src="img/agile-menu-icon.svg"
                                            data-src="img/agile-menu-icon.svg"
                                            alt=">Agile &amp; Scrum"
                                            width="44"
                                            />
                                         <span><strong>Agile &amp; Scrum</strong> Engage with
                                         full trust on every stage.</span></a>
                                      </li>
                                      <li>
                                         <a href="valued-professionals"><img
                                            src="img/scrum-menu-icon.svg"
                                            alt="Valued Professionals"
                                            width="44"/>
                                         <span><strong>Valued Professionals</strong> Know more
                                         about our knowledge pool</span></a>
                                      </li>
                                      <li>
                                         <a href="valued-professionals"><img
                                            src="img/scrum-menu-icon.svg"
                                            alt="Valued Professionals"
                                            width="44"/>
                                         <span><strong>Valued Professionals</strong> Know more
                                         about our knowledge pool</span></a>
                                      </li>
                                   </ul>
                                </div>
                             </div>
                             <!-- tab menu end here -->
                          </div>
                       </div>
                       <div class="seach-btn">
                          <button class="btn"><i class="fas fa-search"></i></button>
                       </div>
                    </div>
                 </div>
                 <div class="col-md-4 col-xs-12">
                    <div class="right-menu">
                       <ul>
                          <li class="flot-right getquote">
                             <a href="cart.php"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i> <span>1</span> <b> ₹ 200</b></a>
                          </li>
                          <li class="flot-right getquote getquote-signs">
                             <a href="cart.php"><i class="far fa-user"></i> Sign In / Login</a>
                          </li>
                          <li class="border-zero flot-right">
                             <a href="javascript:void(0);" id="imgrotate"><img src="img/services-arrow.png" alt="" /></a>
                          </li>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>
        </div>
        <!-- seach box end here -->
        <div class="header-1-top">
           <div class="container1">
              <div class="middelHeader">
                 <div class="container">
                    <nav>
                       <div class="row">
                          <div class="col-md-12 col-xs-12">
                             <div class="collapseNav top-headers">
                                <ul class="first-ul">
                                   <li class="shop">
                                      <a href="javascript:void(0);" id="shopid">Shop By Department <i class="fa fa-angle-down"></i></a>
                                      <div class="top_ul">
                                         <ul class="departmentdks">
                                            <li class="buildings1a...1">
                                               <a href="product-categorys.php">
                                               <span class="img000"><img src="{{static_asset('assets_web/img/icona1.png')}}" alt="" /></span>
                                               <span class="spand-line"><b>All Products</b></span>
                                               </a>
                                            </li>
                                            @foreach ($categories as $key => $category)
                                            <li class="buildings1a">
                                               <a href="{{ route('products.category', $category->slug) }}">
                                               <span class="img000"><img src="{{ uploaded_asset($category->icon) }}" alt="{{translate('icon')}}" /></span>
                                               <span class="spand-line">{{  $category->getTranslation('name') }} <i class="fa fa-angle-right" aria-hidden="true"></i></span>
                                               </a>
                                               <div class="hotkeys_sprite">
                                                  <img src="{{static_asset('assets_web/img/new.png')}}" alt="New"> 
                                               </div>
                                            </li>
                                            @endforeach
                                            <li class="bricka1a">
                                               <a href="electricals.php">
                                               <span class="img000"><img src="{{static_asset('assets_web/img/icona3.png')}}" alt="" /></span>
                                               <span class="spand-line">Electricals <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            <li class="plumbings">
                                               <a href="plumbing.php" ><span class="img000"><img src="{{static_asset('assets_web/img/icona6.png')}}" alt="" /></span>
                                               <span class="spand-line">Plumbing   <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            <li class="constructionsa1">
                                               <a href="sanitary.php"><span class="img000"><img src="img/icona4.png')}}" alt="" /></span>
                                               <span class="spand-line"> Sanitaryware & Bathrobes <i class="fa fa-angle-right" aria-hidden="true"></i></span>  </a>
                                            </li>
                                            <li class="constructionsa1a">
                                               <a href="home-appliances.php"><span class="img000"><img src="{{static_asset('assets_web/img/icona5.png')}}" alt="" /></span>
                                               <span class="spand-line">Home Appliances & Furniture <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            <li class="finishes1a">
                                               <a href="kitchen.php"><span class="img000"><img src="img/icona7.png" alt="" /></span>
                                               <span class="spand-line">Kitchen <i class="fa fa-angle-right" aria-hidden="true"></i></span> </a>
                                            </li>
                                            <li class="electrics1a">
                                               <a href="paint.php"><span class="img000"><img src="img/icona8.png" alt="" /></span>
                                               <span class="spand-line">Paints & Surface Care <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            
                                            <li class="painta1">
                                               <a href="javascript:void(0);"><span class="img000"><img src="img/icona10.png" alt="" /></span>
                                               <span class="spand-line">Wooden & Hardware Tools <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            <li class="kitchens1">
                                               <a href="javascript:void(0);"><span class="img000"><img src="img/icona11.png" alt="" /></span>
                                               <span class="spand-line">Tiles & Floorings <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                            <li class="hardwarea1">
                                               <a href="javascript:void(0);"><span class="img000"><img src="img/icona12.png" alt="" /></span>
                                               <span class="spand-line">Smart Home <i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                                            </li>
                                           
                                         </ul>
                                         <div class="dpeartmens">
                                            <div class="top-megamenu web-mega buildings1a">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                  <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Cements</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  Black Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  White Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  Grey Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="product-building.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Sand & stones</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Aggregate</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Concrete sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    pit sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Steel & TMT</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    TMT Bars
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel Guater
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel T Iron
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Bricks & Blocks</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Bricks Fly Ash
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Red Brick
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Machine made Bricks
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Roofing Solution</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Metal Studding</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> MF Ceiling</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Suspended Ceiling Gridwork</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">timber & board</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> hard wood
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> structural timber</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> soft wood</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Door</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> interior doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> engineered doors</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> solid wooden doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Construction Chemical</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> water proofing
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> hard water solution</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> heat proofing</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Alluminium</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Sliding door
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> sliding windows</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Accessories</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Window</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> steel window
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> wooden window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> upvc window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Garden & Lawn</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> rainwater harvesting
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> garden irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> agricultural irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Construction tools & machinery</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> rajmistri/ mason tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> earthmovig equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> concrete equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Safety </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> site safety
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> personal safety</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega buildings1a1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                  <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Cements</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  Black Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  White Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  Grey Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Sand & stones</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Aggregate</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Concrete sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    pit sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Steel & TMT</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    TMT Bars
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel Guater
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel T Iron
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Bricks & Blocks</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Bricks Fly Ash
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Red Brick
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Machine made Bricks
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Roofing Solution</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Metal Studding</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> MF Ceiling</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Suspended Ceiling Gridwork</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">timber & board</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> hard wood
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> structural timber</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> soft wood</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Door</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> interior doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> engineered doors</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> solid wooden doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Construction Chemical</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> water proofing
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> hard water solution</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> heat proofing</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Alluminium</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Sliding door
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> sliding windows</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Accessories</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Window</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> steel window
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> wooden window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> upvc window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Garden & Lawn</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> rainwater harvesting
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> garden irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> agricultural irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Construction tools & machinery</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> rajmistri/ mason tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> earthmovig equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> concrete equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Safety </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> site safety
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> personal safety</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega constructionsa1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> water closets</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/shower.png" alt="">  intelligent closets
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">  tankless closets
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> touch free closets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Wash basin</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                    Over Counter Basin</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                   Integrated Pedestal Basin
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                    Pedestal Basin-Full
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Cisterns</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                    Concealed Cistern
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                    PVC Cistern
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt="">
                                                                    Ceramic Cistern
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Urinals & Squatting Pans</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Waterless Urinal
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Sensor Urinals
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Standard Urinals
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Faucets</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> centerset </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> single hole</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> wall mount </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Showers</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Digital Shower
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Electric Shower</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Mixer Shower</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Divertors</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Tee Diverter
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Two-Valve Diverter</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Three-way Diverter Valve</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Allied products</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> hoses
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> jet sprays</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> seat covers</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Accessories</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Glass Corner
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Glass Shelf</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Glass Soap Dish</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Bath Tubs</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> generic bathtub
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> soaking bathtub</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> walk-in bathtub</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Shower Enclosures </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Square Shower Enclosure
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Rectangular Shower Enclosure</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Quadrant Shower Enclosure</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                             
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">Differently-Abled</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Water Closets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Matrix Specially Abled</a>
                                                                 </li>
                                                                    <li>
                                                                    <a><img src="img/shower.png" alt=""> Water Closets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                            <li>
                                                              <a href="product-building.php"> <b class="webhead5">Kids Series</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Wash Basin for Kids</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/shower.png" alt=""> Water Closets for Kids</a>
                                                                 </li>
                                                                 
                                                               
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/sanatry1.jpg" alt=""></li>
                                                              <li><img src="img/sanatry2.jpg" alt=""></li>
                                                              <li><img src="img/sanatry3.jpg" alt=""></li>
                                                              <li><img src="img/sanatry4.jpg" alt=""></li>
                                                              <li><img src="img/sanatry5.jpg" alt=""></li>
                                                              <li><img src="img/sanatry6.jpg" alt=""></li>
                                                              <li><img src="img/sanatry7.jpg" alt=""></li>
                                                              <li><img src="img/sanatry8.png" alt=""></li>
                                                              <li><img src="img/sanatry9.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega bricka1a">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Cable and Wire</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/electricity.png" alt=""> Housing Wire
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">  Co axial Cable
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> LAN Cables
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Switches and Socket</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                    Modular Switches</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                   Non Modular Switches
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                   Angle Holder
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Lamp and Lighting </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                  LED Bulbs
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                   LED Ceiling Lights
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">
                                                                   LED Battens
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Door Bell<!----------------------->
     </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Door Bell
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Wired Doorbells
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Wireless Doorbells
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">House wiring pipes</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> PVC Round Type Wiring Duct</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> PVC Trunking and Fittings </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> PVC Conduit and Fittings</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">Switchgears</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Low voltage
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Medium voltage</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> High voltage</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Distribution boards</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Main Breaker Panel</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Main Lug Panel</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Sub-panel </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Plates and Boxes</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Rectangular boxes
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Round pan boxes</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Junction boxes</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Conduits & Fittings</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Adapters
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Bushings</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Couplings</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Metter Box</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> energy meter
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> panel meter</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> meter boxes</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Accessories</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">ceiling rose
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> holders</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> electrical fuse</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Fans</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> ceiling fans
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">wall fans</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> table fans</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Protection Devices </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">mcb
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> elcb or rccb
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> rcbo
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Circuit Breaker & Fuses </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">single-pole
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> double-pole
     
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> GFCI's
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Solar </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt="">Monocrystalline solar panels.
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Polycrystalline solar panels.
     
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/electricity.png" alt=""> Thin film solar panels.
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/electriband1.jpg" alt=""></li>
                                                              <li><img src="img/electriband2.jpg" alt=""></li>
                                                              <li><img src="img/electriband3.jpg" alt=""></li>
                                                              <li><img src="img/electriband4.jpg" alt=""></li>
                                                              <li><img src="img/electriband5.jpg" alt=""></li>
                                                              <li><img src="img/electriband6.jpg" alt=""></li>
                                                              <li><img src="img/electriband7.jpg" alt=""></li>
                                                              <li><img src="img/electriband8.jpg" alt=""></li>
                                                              <li><img src="img/electriband9.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega constructionsa1a">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Furniture seating </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/furnituresss.png" alt=""> Chairs
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">  Stools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">  Bar stools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Tables</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                    Dining tables</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                  Bistro tables
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                   Trestles
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Storage</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                   Shelving
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                    Cabinets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt="">
                                                                    Walk in wardrobes
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Multimedia furnitures</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Multimedia sideboards
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Multimedia cabinets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Multimedia stands
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Bedroom furnitures</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Beds</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Bedframes</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Bed headboards</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">Home appliances</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> air conditioners
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> split ac's</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> window ac's</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Air coolers</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Personal Coolers </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Tower Coolers</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Window Coolers</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Air purifiers</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Ionic Air Purifiers
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Electronic Air Cleaners</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Central Air Cleaners</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Washing machines</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> fully automatic front load
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> fully automatic top load</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> semi-auto top load</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Refrigerators</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> single door
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> double door</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> side by side</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Vaccum cleaners</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Robotic vaccum cleaner
      
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Upright vacuum
      </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Stick vacuum</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">geysers</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> electric gyser
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> gas gyser</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> solar gyser</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">room heaters </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Fan heaters
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Infrared heaters</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/furnituresss.png" alt=""> Oil filled room heaters</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/homeapplince1.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince2.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince3.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince4.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince5.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince6.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince7.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince8.jpg" alt=""></li>
                                                              <li><img src="img/homeapplince9.jpg" alt=""></li>
                                                            </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega plumbings">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Water Pumps</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/plumssbing.png" alt=""> Monoblock Pump
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Sumersible Openwell
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">  Submersible Pumps
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Pipes</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                    UPVC Pipes
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                   HDPE Pipes
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                   PVC Pipes
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Valves</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                   Valves
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                    Washer Flat Fibre
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">
                                                                    Hose Braided Flexible Fxf
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Taps & faucets</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Faucet Accessories
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Divertor
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">Angle Valve
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Showers</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">Shower Arms</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Shower Panel</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">Shower Rooms</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">Drywall</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> boards
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">framing</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> strips & accessories</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Ceiling</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> boards </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> framing systems</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> cornice</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">PVC, CPVC & UPVC Fittings</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Tap
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Plug </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">Bush</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Hoses</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Hoses
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Garden Hose</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Suction Hose</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                          
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Solvents</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> PVC Solvent
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> CPVC Solvent</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> UPVC Solvent</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Water Tank </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Overhead Tank
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Underground Tank </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt="">  Loft Tank </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                            <li>
                                                              <a href="product-building.php"> <b class="webhead11">Accessories & Fittings</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/plumssbing.png" alt=""> Flush Valve
                                                                    </a>
                                                                 </li>
                                                                
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Rain Water Harvester</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                            
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/plumbing1.png" alt=""></li>
                                                              <li><img src="img/plumbing2.jpg" alt=""></li>
                                                              <li><img src="img/plumbing3.jpg" alt=""></li>
                                                              <li><img src="img/plumbing4.jpg" alt=""></li>
                                                              <li><img src="img/plumbing5.jpg" alt=""></li>
                                                              <li><img src="img/plumbing6.jpg" alt=""></li>
                                                              <li><img src="img/plumbing7.jpg" alt=""></li>
                                                              <li><img src="img/plumbing8.jpg" alt=""></li>
                                                              <li><img src="img/plumbing9.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega finishes1a">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> kitchen systems</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  fitted kitchens
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  island kitchens
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  modular kitchens
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  kitchen products</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    kitchen taps
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   kitchen sinks
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    kitchen organization
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">kitchen appliances</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    kitchen hoods
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    cooktop extractor
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    ovens
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">kitchen furniture</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> kitchen cabinets
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> kitchen trolleys
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> kitchen furniture
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">outdoor kitchens</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> modular outdoor kitchens
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> compact outdoor kitchens</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> mobile outdoor kitchen units</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">kichen accessories</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> knife blocks
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> chopping boards</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> kitchen roll holders</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                         
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/kitchen1.jpg" alt=""></li> 
                                                              <li><img src="img/kitchen2.jpg" alt=""></li> 
                                                              <li><img src="img/kitchen3.png" alt=""></li> 
                                                              <li><img src="img/kitchen4.png" alt=""></li> 
                                                              <li><img src="img/kitchen5.jpg" alt=""></li> 
                                                              <li><img src="img/kitchen6.jpg" alt=""></li> 
                                                              <li><img src="img/kitchen7.jpg" alt=""></li> 
                                                              <li><img src="img/kitchen8.jpg" alt=""></li>  
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega webmena1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Cements</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  Black Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  White Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  Grey Cement
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  Sand & stones</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Aggregate</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Concrete sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    pit sand
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Steel & TMT</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    TMT Bars
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel Guater
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    Steel T Iron
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Bricks & Blocks</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Bricks Fly Ash
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Red Brick
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Machine made Bricks
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Roofing Solution</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Metal Studding</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> MF Ceiling</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Suspended Ceiling Gridwork</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">timber & board</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> hard wood
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> structural timber</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> soft wood</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">Door</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> interior doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> engineered doors</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt=""> solid wooden doors </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Construction Chemical</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> water proofing
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> hard water solution</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> heat proofing</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Alluminium</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Sliding door
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> sliding windows</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Accessories</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Window</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> steel window
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> wooden window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt=""> upvc window</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Garden & Lawn</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> rainwater harvesting
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> garden irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt=""> agricultural irrigation</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Construction tools & machinery</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> rajmistri/ mason tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> earthmovig equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> concrete equipment</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Safety </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> site safety
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt=""> personal safety</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega painta1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> planer machine</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  thickness planner
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  surface planner
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt=""> planner machine
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  woodworking tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    wood cutting blade
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   wood cutter
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   carpenter tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">electrical planer</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                   woo dplaner
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                   wood router
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                  electrical router
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">diamond hammer tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> posalux diamond tools
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> industrial diamond tools
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> flywheel diamond tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">plier tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt="">adjustable pliers 
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt="">bending pliers 
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> bent pliers </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">construction tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> mason tools
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> plastering tools
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt=""> plastic scraper</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega kitchens1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Ceramic Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  Ceramic Tiles
                                                                    </a>
                                                                 </li>
                                                                    <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> Terracotta Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    Terracotta Tiles</a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">Marble Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                   Marble Tiles
                                                                    </a>
                                                                 </li>
                                                                
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">Travertine Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Travertine Tiles
                                                                    </a>
                                                                 </li>
                                                                  
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">Granite Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/rosof.png" alt=""> Granite Tiles</a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">Parquet Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/timberd.png" alt="">Parquet Tiles
                                                                    </a>
                                                                 </li>
                                                                
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                          
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9">Concrete Cement Tile</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Concrete Cement Tile
                                                                    </a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead10">Stone Tile</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/elevatorss.png" alt=""> Stone Tile
                                                                    </a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead11">Glass Tile	</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/open-door.png" alt="">Glass Tile	
                                                                    </a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead12">Quarry Tile</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/garden-stools.png" alt="">Quarry Tile
                                                                    </a>
                                                                 </li>
                                                               
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php">  <b class="webhead13">Terrazzo tile</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> Terrazzo tile
                                                                    </a>
                                                                 </li>
                                                                 
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead14">Cladding tile </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/aahelmet.png" alt="">Cladding tile
                                                                    </a>
                                                                 </li>
                                                               
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                            <li>
                                                              <a href="product-building.php"> <b class="webhead7">Vitrified Tiles</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt="">  PGVT Tiles</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/doorq.png" alt="">  GVT Tiles </a>
                                                                 </li>
                                                               
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                            <div class="top-megamenu web-mega hardwarea1">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> access and security</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  alarms
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  detectors
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt=""> door intercoms
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2">  audio / video system</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    audio / video system</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   audio system
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   video system
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3"> electroncs and computers </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                  ict system 
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                  modems
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                   routers
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4">automation</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> touch screens
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> remote controls
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> home automation
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/build-logo.jpg" alt=""></li>
                                                              <li><img src="img/build-logo2.jpg" alt=""></li>
                                                              <li><img src="img/build-logo3.jpg" alt=""></li>
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                          
                                            <div class="top-megamenu web-mega electrics1a">
                                               <!-- mega menu content start here -->
                                               <div class="megamenu megamenu2" style="background: center top rgb(255, 255, 255); display:block ; opacity:1;">
                                                 <div class="row">
                                                     <div class="col-md-8" style="padding-right: 0px">
                                                        <ul class="megamenusubs">
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> wood working machines</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231a">
                                                                 <li>
                                                                    <a href="product-building.php"><img src="img/cementss.png" alt="">  cnc wood router
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt="">  wood cutting machine
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/cementss.png" alt=""> cnc wood carving machine
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead2"> planer machine</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231b">
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                    thickness planner</a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   surface planner
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/stonesd.png" alt="">
                                                                   planner machine
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead3">woodworking tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231c">
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                   wood cutting blade
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                 wood cutter
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/iron-bar.png" alt="">
                                                                    carpenter tools
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead4"> electrical planer </b></a>
                                                              <ul class="megamenusubs231 megamenusubs231d">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> woo dplaner
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> wood router
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> electrical router
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead5">tools parts & others</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231e">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> router bits
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> spindle moulder machine
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> wood crusher</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead6">diamond hammer tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> posalux diamond tools
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> industrial diamond tools
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> flywheel diamond tools</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"> <b class="webhead7">plier tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> adjustable pliers 
      </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> bending pliers 
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> bent pliers </a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           <li>
                                                              <a href="product-building.php"><b class="webhead9"> construction tools</b></a>
                                                              <ul class="megamenusubs231 megamenusubs231f">
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> mason tools
     
                                                                    </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> plastering tools
     </a>
                                                                 </li>
                                                                 <li>
                                                                    <a><img src="img/helxmet.png" alt=""> plastic scraper</a>
                                                                 </li>
                                                                 <li>
                                                                    <a href="#gory.php" class="buildsing">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                                 </li>
                                                              </ul>
                                                           </li>
                                                           
                                                        </ul>
                                                     </div>
                                                     <div class="col-md-4">
                                                        <div class="divcalimmega">
                                                           <h3>Top Brands</h3>
                                                           <ul class="brand-menus">
                                                              <li><img src="img/paint_surface_care/berger.jpg" alt=""></li>
                                                              <li><img src="img/paint_surface_care/asian-paints.jpg" alt=""></li> 
                                                           </ul>
                                                           <img src="img/service-banner-1.png">
                                                           <a class="hire-team-btn" href="javascript:void(0);" target="_self">View More</a>
                                                        </div>
                                                     </div>
                                                  </div>
                                               </div>
                                               <!-- mega menu content end here -->
                                            </div>
                                           
                                         </div>
                                      </div>
                                   </li>
                                   <li class="home">
                                      <a href="javascript:void(0);"><i class="fas fa-home"></i></a>
                                   </li>
                                  
                                   <li class="menulocationds menulocationds1 com">
                                      <a href="#s">Company</a>
                                      <div class="megamenu megamenu1" style="
                                         background-image: url(img/megamenusbanner.png);
                                         background-size: cover;
                                         background: #fff;
                                         background-position: top center;
                                         ">
                                         <div class="submenu submenu4">
                                            <div class="submenu4_top">
                                               <div class="submenu4_top1" style="background-image: url(img/web-icon15.png);background-size: 20px; background-position: top left;">
                                                  <a href="javascript:void(0);">
                                                     <h3>About Us</h3>
                                                     <p>
                                                        ACSIUS, an ISO 9001:2015 certified Web Design Company.
                                                     </p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top2" style="  background-image: url(img/web-icon16.png);background-size: 20px; background-position: top left;">
                                                  <a href="javascript:void(0);">
                                                     <h3>Blog</h3>
                                                     <p>
                                                        A perspective to talk about new ideas, future technology and its impact on enterprises.
                                                     </p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top3" style=" background-image: url(img/web-icon17.png); background-size: 20px; background-position: top left; ">
                                                  <a href="testimonials">
                                                     <h3>Testimonials</h3>
                                                     <p>See what people have to say about us.</p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top4" style=" background-image: url(img/web-icon18.png); background-size: 20px; background-position: top left; ">
                                                  <a href="javascript:void(0);">
                                                     <h3>Press &amp; Media</h3>
                                                     <p>Knowing Us in Interesting Ways</p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top4" style=" background-image: url(img/web-icon19.png);background-size: 20px; background-position: top left;">
                                                  <a href="javascript:void(0);">
                                                     <h3>Press &amp; Media</h3>
                                                     <p>Knowing Us in Interesting Ways</p>
                                                  </a>
                                               </div>
                                            </div>
                                            <div class="submenu4_bot">
                                               <div class="submenu4_botlt">
                                                  <h3>The Next Level Knowledge Awaits</h3>
                                                  <p>
                                                     Make your web presence impressive by getting precise web design, digital marketing, mobile responsive website, web development and complete IT solutions from certified experts.
                                                  </p>
                                               </div>
                                               <div class="submenu4_botrt">
                                                  <a href="contact-us" class="borderbtn1">Talk To Our Experts</a
                                                     >
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   </li>
                                   <!-- PRODUCT START HERE -->
                                   <li class="menulocationds menulocationds5 com">
                                      <a href="#folio">Pro-Services</a>
                                      <!-- mega sub menu start here -->
                                      <div class="product_submenu">
                                         <ul>
                                         <li>
                                               <div class="sub-menu-item">
                                                  <a href="turnkey-services.php" class="ProductLink">
                                                     <img src="img/endconsulants1.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Turnkey Services </h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="end_to_end_construction.php">  End To End Construction </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Renovation</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Interior </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Architecture </a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="architect-services.php" class="ProductLink">
                                                     <img src="img/architect.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Architect</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);">Residential Architects </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Society Architects</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Structural Design Architects</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Commercial Architects</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="cost-cunsl-services.php" class="ProductLink">
                                                     <img src="img/cost.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Cost consultant</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Whole life solution </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Pre-tender estimate</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Elemental cost plan</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Chartered surveyor</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="services-engineer-services.php" class="ProductLink">
                                                     <img src="img/services-enginer.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Services Engineer</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);">  Occupant subjectivity</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Thermal comfort</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Mechanical ventilation </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Insulation specification</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="structural-engeeniring-services.php" class="ProductLink">
                                                     <img src="img/structural1.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Structural Engineer</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Structural Observations </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Design Everest</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Seismic concerns </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Code compliance</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="interior-desgine-services.php" class="ProductLink">
                                                     <img src="img/interiordesigner1.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Interior Designer</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Modular Kitchens</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Furniture</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Lighting</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Painting & Wallpaper</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="vastu-services.php" class="ProductLink">
                                                     <img src="img/vastu.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Vastu / Archaeologist</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Vastu Interior Designer </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Vastu Architecture</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Vastu Designer </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Vastu Architecture Services</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="labour-supplier-services.php" class="ProductLink">
                                                     <img src="img/labur11.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Labour Suppliers</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Proofing construction </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Construction disputes</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Buildability in construction </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Smart construction</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="contractor-services.php" class="ProductLink">
                                                     <img src="img/contractor11.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Contractor</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Turnkey Contractor </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Civil contractor</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Slab casting contractor </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);">Ironworker </a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                            <li>
                                               <div class="sub-menu-item">
                                                  <a href="exterior-desgine-services.php" class="ProductLink">
                                                     <img src="img/exteriordesign.jpg" class="NavThumbnail" alt="Kitchen Pannels" />
                                                     <h3>Exterior Design</h3>
                                                  </a>
                                                  <ol>
                                                     <li>
                                                        <a href="javascript:void(0);"> Modular kitchen designer</a>
                                                        <div class=""></div>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Modular wordrobe designer</a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Commercial Spaces Interiors </a>
                                                     </li>
                                                     <li>
                                                        <a href="javascript:void(0);"> Hotel Interior designing</a>
                                                     </li>
                                                  </ol>
                                               </div>
                                            </li>
                                         </ul>
                                         <div class="laminates-more">
                                            <div class="submenu4_bot">
                                               <div class="submenu4_botlt">
                                                  <h3>The Next Level Knowledge Awaits</h3>
                                                  <p>
                                                     Make your web presence impressive by getting precise web design, digital marketing, mobile responsive website, web development and complete IT solutions from certified experts.
                                                  </p>
                                               </div>
                                               <div class="submenu4_botrt">
                                                  <a href="contact-us" class="borderbtn1">Talk To Our Experts</a
                                                     >
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                      <!-- mega sub menu end here -->
                                   </li>
                                   <!-- PRODUCT END HERE -->
                                   <li class="menulocationds menulocationds2 com">
                                      <a href="#s">Products </a>
                                      <div class="megamenu megamenu2" style="
                                         background-image: url(img/megamenusbanner.png);
                                         background-size: cover;
                                         background: #fff;
                                         background-position: top center;
                                         ">
                                         <div class="row">
                                            <div class="col-md-8" style="padding-right: 0px">
                                               <ul class="megamenusubs">
                                                  <li>
                                                     <a href="product-category.php" style="    padding: 0px;"><b class="webhead1">Building Materials</b></a>
                                                     <ul class="megamenusubs231 megamenusubs231a">
                                                        <li>
                                                           <a href="product.php"><img src="img/mechanic-tools.png" alt="" /> Cement
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/construction.png" alt="" /> Bricks & Blocks
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/windows.png" alt="" /> Sand & Jelly
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/furnitures.png" alt="" /> Steel & Tmt
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a href="product-category.php" style="color: #1274c0; font-weight: 700;letter-spacing: 0.5px;">  View More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                                  <li>
                                                     <b class="webhead2">Electrical</b>
                                                     <ul
                                                        class="megamenusubs231 megamenusubs231b"
                                                        >
                                                        <li>
                                                           <a><img src="img/smart-lighting.png" alt="" />
                                                           Lighting </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/cable.png" alt="" />
                                                           Cables
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/breaker.png" alt="" />
                                                           Circuit Breakers
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/carpenter.png" alt="" />
                                                           Carpenter
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/electric-tower.png" alt="" />
                                                           Conduits & Accessories
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/electrical-panel.png" alt="" />
                                                           Distribution Board
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/switchboard.png" alt="" />
                                                           Switches & Sockets
                                                           </a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                                  <li>
                                                     <b class="webhead3">Plumbing</b>
                                                     <ul
                                                        class="megamenusubs231 megamenusubs231c"
                                                        >
                                                        <li>
                                                           <a
                                                              ><img src="img/bath.png" alt="" />
                                                           Bathroom Fittings
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/fitting-room.png" alt="" />
                                                           Fittings</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/pipe.png" alt="" />
                                                           PVC Pipes
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/pipes.png" alt="" />
                                                           CPVC Pipes
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/natural-gas.png" alt="" />
                                                           UPVC Pipes
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/outdoor-table.png" alt="" />
                                                           Outdoor Fittings
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/roof.png" alt="" />
                                                           Roof & Floor
                                                           </a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                                  <li>
                                                     <b class="webhead4">Finishing Materials</b>
                                                     <ul class="megamenusubs231 megamenusubs231d">
                                                        <li>
                                                           <a><img src="img/tiles.png" alt="" />Tiles </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/dance-floor.png" alt="" /> Flooring
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/landscape.png" alt="" /> Landscaping
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/roofs.png" alt="" /> Roofing
                                                           </a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                                  <li>
                                                     <b class="webhead5">Material </b>
                                                     <ul class="megamenusubs231 megamenusubs231e">
                                                        <li>
                                                           <a><img src="img/constructionaa.png" alt="" /> Building blocks</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/tools.png" alt="" /> Carpentry</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/ceiling-light.png" alt="" /> Ceilings</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/brick.png" alt="" /> Inner walls</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/metallic-tower.png" alt="" /> Metal structures </a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                                  <li>
                                                     <b class="webhead6">Tech</b>
                                                     <ul class="megamenusubs231 megamenusubs231f">
                                                        <li>
                                                           <a><img src="img/cloud.png" alt="" /> Access and security
                                                           </a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/audio-editing.png" alt="" /> Audio video systems</a>
                                                        </li>
                                                        <li>
                                                           <a><img src="img/automation.png" alt="" /> Automation</a>
                                                        </li>
                                                     </ul>
                                                  </li>
                                               </ul>
                                            </div>
                                            <div class="col-md-4">
                                               <div class="divcalimmega">
                                                  <h3>Hire Team</h3>
                                                  <p>
                                                     Hire our dedicated team who will prove to be the biggest sources to help your businesses with cost-effective method.
                                                  </p>
                                                  <img src="img/service-banner-1.png" />
                                                  <a class="hire-team-btn" href="javascript:void(0);" target="_self">Hire Team</a
                                                     >
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   </li>
                                   <li class="menulocationds menulocationds3 com">
                                      <a href="#s">Build Expertise </a>
                                      <div class="megamenu megamenu3" style="
                                         background-image: url(img/megamenusbanner.png);
                                         background-size: cover;
                                         background: #fff;
                                         background-position: top center;
                                         ">
                                         <div class="submenu submenu3">
                                            <div class="menuleft menuleft3">
                                               <h3><span>Hire</span> Remote Team</h3>
                                               <img class="lazyloaded" src="img/hire-team-photo.png" data-src="img/hire-team-photo.png" alt="Team Photos" />
                                               <a href="technology-expertise#tab2" class="borderbtn1">Hire Now</a
                                                  >
                                            </div>
                                            <div class="menuright menuright3">
                                               <ul>
                                                  <li>
                                                     <a href="technology-expertise#tab2">
                                                     <img
                                                        class="lazyloaded"
                                                        src="img/technology-menu-icon.svg"
                                                        data-src="img/technology-menu-icon.svg"
                                                        alt="Technology"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Residential</strong> Home</span
                                                        ></a
                                                        >
                                                  </li>
                                                  <li>
                                                     <a href="4p"
                                                        ><img
                                                        src="img/4p-menu-icon.svg"
                                                        alt="4p"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Commercial</strong> Building
                                                     Development.</span
                                                        ></a
                                                        >
                                                  </li>
                                                  <li>
                                                     <a href="models"
                                                        ><img
                                                        src="img/models-menu-icon.svg"
                                                        alt="models"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>architect</strong> Building <br>Design</span></a
                                                        >
                                                  </li>
                                                  <li>
                                                     <a href="agile-and-scrum"
                                                        ><img
                                                        class="lazyloaded"
                                                        src="img/agile-menu-icon.svg"
                                                        data-src="img/agile-menu-icon.svg"
                                                        alt=">Agile &amp; Scrum"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Interior / Exterior</strong>Designing</span></a>
                                                  </li>
                                                  <li>
                                                     <a href="valued-professionals"
                                                        ><img
                                                        src="img/scrum-menu-icon.svg"
                                                        alt="Valued Professionals"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Building </strong><br> Material Supply</span>
                                                     </a>
                                                  </li>
                                                  <li>
                                                     <a href="valued-professionals"
                                                        ><img
                                                        src="img/scrum-menu-icon.svg"
                                                        alt="Valued Professionals"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Talk to</strong> experts</span>
                                                     </a>
                                                  </li>
                                                  <li>
                                                     <a href="valued-professionals"
                                                        ><img
                                                        src="img/scrum-menu-icon.svg"
                                                        alt="Valued Professionals"
                                                        width="44"
                                                        />
                                                     <span
                                                        ><strong>Plumber / Electrician </strong> experts</span>
                                                     </a>
                                                  </li>
                                               </ul>
                                            </div>
                                         </div>
                                      </div>
                                   </li>
                                   <li class="menulocationds menulocationds4 com">
                                      <a href="#s">Partner With Us</a>
                                      <div class="megamenu megamenu4" style="
                                         background-image: url(img/megamenusbanner.png);
                                         background-size: cover;
                                         background: #fff;
                                         background-position: top center;
                                         ">
                                         <div class="submenu submenu4">
                                            <div class="submenu4_top">
                                               <div class="submenu4_top1">
                                                  <a href="javascript:void(0);">
                                                     <h3>Sales Partner</h3>
                                                     <p>
                                                        Our prowess to create growth, generate productivity and help launch new business models.
                                                     </p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top2">
                                                  <a href="javascript:void(0);">
                                                     <h3>material Suppliers</h3>
                                                     <p>
                                                        A perspective to talk about new ideas, future technology and its impact on enterprises.
                                                     </p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top3">
                                                  <a href="testimonials">
                                                     <h3>Labour Suppliers</h3>
                                                     <p>See what people have to say about us.</p>
                                                  </a>
                                               </div>
                                               <div class="submenu4_top4">
                                                  <a href="javascript:void(0);">
                                                     <h3>Engineer and Architect Associates</h3>
                                                     <p>Knowing Us in Interesting Ways</p>
                                                  </a>
                                               </div>
                                            </div>
                                            <div class="submenu4_bot">
                                               <div class="submenu4_botlt">
                                                  <h3>The Next Level Knowledge Awaits</h3>
                                                  <p>
                                                     Learn more about the innumerable possibilities that can be unleashed by bridging the gap between aspiration and realization with the right technology and smart resources.
                                                  </p>
                                               </div>
                                               <div class="submenu4_botrt">
                                                  <a href="contact-us" class="borderbtn1">Talk To Our Experts</a
                                                     >
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   </li>
                                   <li class="com more_tabs">
                                      <a href="#tact-us">More</a>
                                      <div class="tab-more">
                                         <ul>
                                            <li><a href="javascript:void(0);"><img src="img/visualizer.png" alt=""> Visuliazer</a></li>
                                            <li><a href="javascript:void(0);"><img src="img/freesampleorder.png" alt=""> Order free sample</a></li>
                                            <li><a href="javascript:void(0);"><img src="img/explorer.jpg" alt=""> Design explorer</a></li>
                                            <li><a href="javascript:void(0);"><img src="img/web-icon17.png" alt=""> Testimonials</a></li>
                                            <li><a href="javascript:void(0);"><img src="img/web-icon16.png" alt=""> Blog </a></li>
                                            <li><a href="javascript:void(0);"><img src="img/icona1.png" alt=""> Career</a></li>
                                            <li><a href="javascript:void(0);"><i class="fa-solid fa-address-book"></i> Contact Us</a></li>
                                         </ul>
                                      </div>
                                   </li>
                                </ul>
                             </div>
                          </div>
                       </div>
                    </nav>
                 </div>
              </div>
           </div>
        </div>
        <div class="header-inner">
           <div class="logo-container">
              <div class="container">
                 <div class="landing-logo">
                    <a class="navbar-brand" href="javascript:void(0);"><img src="img/icon.png" /></a>
                 </div>
                 <div class="mobile-logo">
                    <a class="navbar-brand" href="javascript:void(0);"><img src="img/icon.png" /></a>
                 </div>
                 <div class="humberg-menu">
                    <span></span> <span class="middle"></span> <span></span>
                 </div>
              </div>
           </div>
           <div class="popmenu-container">
              <a href="javascript:void(0);" class="close-menu"><img src="img/close.png" alt="" /></a>
              <div class="menu-overlay"></div>
              <div class="left-side-bar">
                 <ul class="menu-list">
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-house"></i>&nbsp; ask group</a
                          >
                    </li>
                    <li>
                       <a href="javascript:void(0);"
                          ><i class="fa-solid fa-kit-medical"></i>&nbsp; ask wealth
                       advisors <b class="caret"></b
                          ></a>
                       <div class="menu-sub-list">
                          <ul>
                             <li><a href="javascript:void(0);">About Us</a></li>
                             <li><a href="javascript:void(0);">Our Companies</a></li>
                             <li><a href="javascript:void(0);">Our Board Member</a></li>
                             <li><a href="javascript:void(0);">Our Team</a></li>
                             <li><a href="javascript:void(0);">Ask Foundation</a></li>
                             <li><a href="javascript:void(0);">Disclosure</a></li>
                          </ul>
                       </div>
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-user-tie-hair"></i> &nbsp; ask
                       investment managers</a
                          >
                    </li>
                    <li>
                       <a href="javascript:void(0);"
                          ><i class="fa-solid fa-house"></i>&nbsp; ask property
                       investment
                       </a>
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-house"></i>&nbsp; ask capital
                       management
                       </a>
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-headphones-simple"></i> &nbsp; ask
                       pravi</a
                          >
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-play"></i> &nbsp; media </a>
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-book"></i>&nbsp; careers</a>
                    </li>
                    <li>
                       <a href="javascript:void(0);"><i class="fa-solid fa-headphones-simple"></i> &nbsp; contact
                       us</a
                          >
                    </li>
                 </ul>
                 <div class="right-0 bottom-0 left-0 z-index-n1">
                    <svg
                       xmlns="http://www.w3.org/2000/svg"
                       xmlns:xlink="http://www.w3.org/1999/xlink"
                       x="0px"
                       y="0px"
                       viewBox="0 0 300 126.5"
                       style="
                       margin-bottom: -5px;
                       enable-background: new 0 0 300 126.5;
                       "
                       xml:space="preserve"
                       class="injected-svg js-svg-injector"
                       data-parent="#SVGwaveWithDots"
                       >
                       <style type="text/css">
                          .wave-bottom-with-dots-0 {
                          fill: #377dff;
                          }
                          .wave-bottom-with-dots-1 {
                          fill: #377dff;
                          }
                          .wave-bottom-with-dots-2 {
                          fill: #de4437;
                          }
                          .wave-bottom-with-dots-3 {
                          fill: #00c9a7;
                          }
                          .wave-bottom-with-dots-4 {
                          fill: #ffc107;
                          }
                       </style>
                       <path
                          class="wave-bottom-with-dots-0 fill-primary"
                          opacity=".6"
                          d="M0,58.9c0-0.9,5.1-2,5.8-2.2c6-0.8,11.8,2.2,17.2,4.6c4.5,2.1,8.6,5.3,13.3,7.1C48.2,73.3,61,73.8,73,69  c43-16.9,40-7.9,84-2.2c44,5.7,83-31.5,143-10.1v69.8H0C0,126.5,0,59,0,58.9z"
                          ></path>
                       <path
                          class="wave-bottom-with-dots-1 fill-primary"
                          d="M300,68.5v58H0v-58c0,0,43-16.7,82,5.6c12.4,7.1,26.5,9.6,40.2,5.9c7.5-2.1,14.5-6.1,20.9-11  c6.2-4.7,12-10.4,18.8-13.8c7.3-3.8,15.6-5.2,23.6-5.2c16.1,0.1,30.7,8.2,45,16.1c13.4,7.4,28.1,12.2,43.3,11.2  C282.5,76.7,292.7,74.4,300,68.5z"
                          ></path>
                       <g>
                          <circle
                             class="wave-bottom-with-dots-2 fill-danger"
                             cx="259.5"
                             cy="17"
                             r="13"
                             ></circle>
                          <circle
                             class="wave-bottom-with-dots-1 fill-primary"
                             cx="290"
                             cy="35.5"
                             r="8.5"
                             ></circle>
                          <circle
                             class="wave-bottom-with-dots-3 fill-success"
                             cx="288"
                             cy="5.5"
                             r="5.5"
                             ></circle>
                          <circle
                             class="wave-bottom-with-dots-4 fill-warning"
                             cx="232.5"
                             cy="34"
                             r="2"
                             ></circle>
                       </g>
                    </svg>
                 </div>
              </div>
           </div>
        </div>
     </header>
	 