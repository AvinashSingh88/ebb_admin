<table class="table3 table-cartsummary">
    <tbody>
       <tr class="bd-nn1 mb-3">
          <td class="w-75 border-0">Price (<span class="cart_count"></span> Item)</td>
          <td class="w-25 border-0">₹ <span>{{$total}}</span></td>
       </tr>
       <tr class="bd-nn1 mb-3 border-0">
          <td class="w-75  border-0">Delivery Charge</td>
          <td class="w-25  border-0">₹ <span>700</span></td>
       </tr>
       <tr class="amount-pay">
          <td class="w-75">Amount Payable</td>
          <td class="w-25">₹ <span>76212</span></td>
       </tr>
    </tbody>
 </table>